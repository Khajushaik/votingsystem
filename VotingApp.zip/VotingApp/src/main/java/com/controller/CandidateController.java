package com.controller;

import java.security.Principal;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.model.Candidate;
import com.service.CandidateService;

@Controller
public class CandidateController {
    
    @Autowired
    private CandidateService cndServ;

    @PostMapping("/addcandidate")
    public String addCandidate(
            @RequestParam("candidate") String candidate,
            Principal p,
            Model model,
            HttpSession session) {
        String email = p.getName();
        
        if (cndServ.getCandByUser(email) != null) {
            // If the user has already voted, return the "alreadyVotedPage" HTML file
            return "alreadyvoted";
        } else {
            String candidate1 = "";
            String candidate2 = "";
            String candidate3 = "";
            String candidate4 = "";

            if ("candidate1".equals(candidate))
                candidate1 = email;
            else if ("candidate2".equals(candidate))
                candidate2 = email;
            else if ("candidate3".equals(candidate))
                candidate3 = email;
            else if ("candidate4".equals(candidate))
                candidate4 = email;

            Candidate cnd = new Candidate();
            cnd.setCandidate1(candidate1);
            cnd.setCandidate2(candidate2);
            cnd.setCandidate3(candidate3);
            cnd.setCandidate4(candidate4);

            cndServ.addCandidate(cnd);
            
            // If the user successfully voted, return the "successPage" HTML file
            return "about";
        }
    }
}
