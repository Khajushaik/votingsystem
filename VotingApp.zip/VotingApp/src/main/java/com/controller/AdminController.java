package com.controller;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.model.Admin;
import com.model.Candidate;
import com.model.Role;
import com.model.User;
import com.service.AdminService;
import com.service.CandidateService;
import com.service.RoleService;
import com.service.UserService;


@Controller
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	private CandidateService cndServ;
	
	@Autowired
	private AdminService admServ;
	
	@Autowired
	private UserService userServ;
	
	@Autowired
	private RoleService roleServ;
		
		
//=======================================================================================================================================	
	@RequestMapping("")
	public String dashboard(Model m, Principal p) {
	    // Calculate total number of votes for each candidate
	    int c1 = 0;
	    int c2 = 0;
	    int c3 = 0;
	    int c4 = 0;

	    List<Candidate> listc = cndServ.getAllCandidates();
	    for (Candidate v : listc) {
	        if (!v.getCandidate1().equals(""))
	            c1++;
	        if (!v.getCandidate2().equals(""))
	            c2++;
	        if (!v.getCandidate3().equals(""))
	            c3++;
	        if (!v.getCandidate4().equals(""))
	            c4++;
	    }

	    // Print the vote counts
	    System.out.println(c1);
	    System.out.println(c2);
	    System.out.println(c3);
	    System.out.println(c4);

	    // Add vote counts to the model
	    m.addAttribute("c1", c1);
	    m.addAttribute("c2", c2);
	    m.addAttribute("c3", c3);
	    m.addAttribute("c4", c4);

	    m.addAttribute("title", "Admin Home");

	    // Calculate the maximum votes
	    int maxVotes = Math.max(c1, Math.max(c2, Math.max(c3, c4)));

	    // Create a list to store the winning candidates
	    List<String> winners = new ArrayList<>();

	    // Check which candidates have the highest vote count and add them to the winners list
	    if (c1 == maxVotes) {
	        winners.add("Candidate 1");
	    }
	    if (c2 == maxVotes) {
	        winners.add("Candidate 2");
	    }
	    if (c3 == maxVotes) {
	        winners.add("Candidate 3");
	    }
	    if (c4 == maxVotes) {
	        winners.add("Candidate 4");
	    }

	    // Add the winners list to the model
	    m.addAttribute("winners", winners);

	    // ... Existing code for adding other attributes ...

	    // New code for creating the data for the chart
	    List<String> candidates = new ArrayList<>();
	    candidates.add("Candidate 1");
	    candidates.add("Candidate 2");
	    candidates.add("Candidate 3");
	    candidates.add("Candidate 4");

	    List<Integer> voteCounts = new ArrayList<>();
	    voteCounts.add(c1);
	    voteCounts.add(c2);
	    voteCounts.add(c3);
	    voteCounts.add(c4);

	    m.addAttribute("candidates", candidates);
	    m.addAttribute("voteCounts", voteCounts);

	    return "admin/dashboard";
	}

//=======================================================================================================================================	
	
	// viewadmins
	@GetMapping("/viewadmins")
				@RequestMapping("viewadmins")
				public String viewadmins(Model m)
				{
					String dest = "viewadmins";
					
					
					List<Admin> admins = admServ.getAllAdmin();
					
					m.addAttribute("admins", admins);
					m.addAttribute("title","View Admins");
					
					return "admin/viewadmins";
				}
	@GetMapping("/register")
	public String register(Model m)
	{
		m.addAttribute("title","Registration");
		return "admin/register";
//=======================================================================================================================================	
	}
	@PostMapping("/createuser")
	public String createuser(@ModelAttribute User user,HttpSession session)
	{		
		int i= 0;
		
		try
		{
		String email = user.getEmail();
		
			if(userServ.getUserByEmail(email) != null)
			{
				i++;
			}
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		if(i >= 1)
		{
			session.setAttribute("msg","Registration Failed,Please try different email id");
			return "redirect:/register";
		}
			List<Role> r = new ArrayList<>();
			r.add(roleServ.getRoleByName("ROLE_USER"));
		
			user.setRoles(r);
			 userServ.addUser(user);
			
			session.setAttribute("msg","Voter Adding Successful...");
			
			return "redirect:/admin/register";
		
		
	}
	// viewusers
			@GetMapping("viewusers")
			public String viewuser(Model m)
			{
				
				
				List<User> users = userServ.getAllUsers();
				
				m.addAttribute("users", users);
				m.addAttribute("title","All Voter's Details");
				
				return "admin/viewusers";
			}
				
			
			// view user which is to update
			@GetMapping("/edituser/{id}")
			public String edit(@PathVariable int id,Model m)
			{
				User user = userServ.getUserById(id);
					
				m.addAttribute("user",user);
				
				return "admin/edituser";
			}
			
			// update user
			@PostMapping("/updateuser")
			public String updateemp(@ModelAttribute User user,javax.servlet.http.HttpSession session)
			{
				userServ.addUser(user);
				
				session.setAttribute("msg", "User updated successfully...");
				
				return "redirect:/admin/viewusers";
			}
				
			// delete user
			@GetMapping("/deleteuser/{id}")
			public String deleteemp(@PathVariable int id,HttpSession session)
			{
				userServ.deleteUser(id);
				
				session.setAttribute("msg", "User deleted successfully...");
				
				return "redirect:/admin/viewusers";
			}
			 @GetMapping("/adduser")
			    public String showAddUserForm(Model model) {
			        // Create a new User object to bind form data
			        User newUser = new User();
			        model.addAttribute("newUser", newUser);
			        return "admin/adduser";
			    }

			    // Handle the form submission to add a new member
			    @PostMapping("/adduser")
			    public String addUser(@ModelAttribute("newUser") User newUser) {
			        // Add the new user/member to your system using the userService
			        userServ.addUser(newUser);

			        // Redirect to a success page or any other appropriate page
			        return "redirect:/admin/viewusers";
			    }
//=======================================================================================================================================	
				
			// viewcandidates
						@GetMapping("votedetails")
						public String viewcandidates(Model m)
						{
							
							List<Candidate> candidates = cndServ.getAllCandidates();
						
							m.addAttribute("candidates", candidates);
							m.addAttribute("title","All Votes Details");
							
							
							// view total number of votes
							int c1=0;
							int c2=0;
							int c3=0;
							int c4=0;
							
							List<Candidate> listc = cndServ.getAllCandidates();
							for(Candidate v : listc)
							{
								if(!v.getCandidate1().equals(""))
									c1= c1 + 1;
								if(!v.getCandidate2().equals(""))
									c2= c2 + 1;
								if(!v.getCandidate3().equals(""))
									c3= c3 + 1;
								if(!v.getCandidate4().equals(""))
									c4= c4 + 1;
							}
							
							m.addAttribute("c1",c1);
							m.addAttribute("c2",c2);
							m.addAttribute("c3",c3);
							m.addAttribute("c4",c4);
							
							
							return "admin/votedetails";
						}
						
						
			
						// deletecandidate
						
						@GetMapping("/deletecandidate/{id}")
						public String deleteVote(@PathVariable("id") int id,HttpSession session)
						{
							
							cndServ.deleteCandidate(id);
							session.setAttribute("msg", "Vote Deleted Sucessfully");
							
							return "redirect:/admin/votedetails";
						}			
			
			
			
			
	
//=======================================================================================================================================	
	
}
