package com.controller;



import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.model.Role;
import com.model.User;
import com.service.RoleService;
import com.service.UserService;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;



@Controller
public class HomeController {
	
	
	@Autowired
	private UserService userserv;
	
	@Autowired
	private RoleService roleserv;

	@GetMapping("/")
	public String index(Model m)
	{
		
		m.addAttribute("title","Home");
		return "home";
	}
	
	
	
	@GetMapping("/signin")
	public String signin(Model m)
	{
		m.addAttribute("title","Signin");
		return "signin";
	}
	
	
	
	
	@GetMapping("/register")
	public String register(Model m)
	{
		m.addAttribute("title","Registration");
		return "register";
	}
	
	
	@GetMapping("/about")
	public String about(Model m)
	{
		m.addAttribute("title","About");
		return "about";
	}

	@GetMapping("/alreadyvoted")
	public String alreadyvoted(Model m)
	{
		m.addAttribute("title","About");
		return "alreadyvoted";
	}
	
	@Autowired
	private JavaMailSender emailSender;
	@PostMapping("/createuser")
	public String createuser(@ModelAttribute User user, HttpSession session) {
	    int i = 0;

	    try {
	        String email = user.getEmail();

	        if (userserv.getUserByEmail(email) != null) {
	            i++;
	        }
	    } catch (Exception e) {
	        System.out.println(e);
	    }

	    if (i >= 1) {
	        session.setAttribute("msg", "Registration Failed, Please try a different email id");
	        return "redirect:/admin/register";
	    }

	    List<Role> r = new ArrayList<>();
	    r.add(roleserv.getRoleByName("ROLE_USER"));
	    user.setRoles(r);
	    userserv.addUser(user);

	    // Send an email with the user's credentials
	    SimpleMailMessage message = new SimpleMailMessage();
	    message.setTo(user.getEmail());
	    message.setSubject("Successfully Added To Democratic Voting");
	    message.setText("Thank you for registering! You have been successfully added to the voting community.\n\n"
	            + "Your login credentials:\nEmail: " + user.getEmail() + "\nPassword: " + user.getPassword()
	            + "\n\nYou can now vote using these credentials. Login Link : http://localhost:9002/");

	    try {
	        emailSender.send(message);
	        session.setAttribute("msg", "Registration Successful and Mail sent to Voter");
	    } catch (Exception ex) {
	        // Handle email sending errors
	        System.out.println("Error sending email: " + ex.getMessage());
	        session.setAttribute("msg", "Registration Successful, but there was an issue sending the email.");
	    }

	    return "redirect:/admin/register";
	}

}


